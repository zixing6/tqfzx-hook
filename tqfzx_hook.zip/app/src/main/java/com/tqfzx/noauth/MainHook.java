package com.tqfzx.noauth;

import android.app.Activity;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 台球辅助线 (com.tqfzx) 去卡密弹窗模块
 *
 * 原理: 该 App 通过 LarkShadow 插件框架加载 plugin.apk,
 *       插件内 MainActivity.onCreate() 会启动任务调度引擎 (l0.b -> l0.e.f()),
 *       逐个执行任务队列 (l0.e.a() 组装), 其中含卡密任务 (z0.k / z0.s),
 *       由任务的 d(Activity) 弹出卡密/激活界面。
 *
 * 本模块运行时: 1) 从插件 MainActivity 拿到插件 ClassLoader;
 *               2) hook l0.e.a(), 把返回任务列表中的 z0.k / z0.s 移除;
 *               3) 兼 hook z0.k.d() / z0.s.d(), 直接 return 绝不弹窗。
 * 完全运行时, 不改 apk, 不碰加固壳, 绕开签名。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "TqfzxNoAuth";
    private static final String PKG = "com.tqfzx";
    // 插件内关键类 (descriptor-free, 用点分名)
    private static final String CLS_MAIN_ACTIVITY = "com.lark.injector.plugin.MainActivity";
    private static final String CLS_TASK_ENGINE = "l0.e";   // 任务队列工厂 l0.e.a()
    private static final String CLS_REG_FULL = "z0.k";       // RegisterTask (显示注册任务)
    private static final String CLS_REG_CODE = "z0.s";       // 激活码界面

    private volatile boolean hooked = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // 目标进程: 包名就是 com.tqfzx, 以及其子进程(:probe/:lark_pluginN 等进程名形如 com.tqfzx:xxx)
        if (lpparam.packageName == null || !lpparam.packageName.startsWith(PKG)) {
            return;
        }
        Log.i(TAG, "loaded in process: " + lpparam.processName + " pkg=" + lpparam.packageName);

        // 方案一: 直接在本进程 classLoader 中尝试 hook(插件类可能已在本进程 loader 可见)
        tryHookWithLoader(this.getClass().getClassLoader());
        tryHookWithLoader(lpparam.classLoader);

        // 方案二(兜底且最可靠): hook 插件 MainActivity.onCreate, 拿到插件真实 ClassLoader 后再 hook
        try {
            Class<?> mainAct = XposedHelpers.findClass(CLS_MAIN_ACTIVITY, lpparam.classLoader);
            XposedBridge.hookAllMethods(mainAct, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Object act = param.thisObject;
                        if (act != null) {
                            ClassLoader cl = act.getClass().getClassLoader();
                            Log.i(TAG, "got plugin classloader from MainActivity: " + cl);
                            tryHookWithLoader(cl);
                        }
                    } catch (Throwable t) {
                        Log.e(TAG, "after onCreate err", t);
                    }
                }
            });
            Log.i(TAG, "hooked MainActivity.onCreate for classloader capture");
        } catch (Throwable t) {
            Log.e(TAG, "find MainActivity failed: " + t);
        }
    }

    /** 用给定 ClassLoader 尝试加载目标类并 hook; 幂等 */
    private synchronized void tryHookWithLoader(ClassLoader cl) {
        if (cl == null) return;
        // 先探测能否加载任务引擎类
        Class<?> engine;
        try {
            engine = Class.forName(CLS_TASK_ENGINE, false, cl);
        } catch (Throwable t) {
            // 本 loader 还看不到插件类, 静默返回(等其他时机)
            return;
        }
        if (hooked) return;
        hooked = true;
        Log.i(TAG, "hooking target classes with loader: " + cl);

        // 1) hook l0.e.a(Lv0/X;)Ljava/util/ArrayList;  -> after 移除卡密任务
        try {
            Method aMethod = null;
            for (Method m : engine.getDeclaredMethods()) {
                if (m.getName().equals("a")
                        && m.getParameterTypes().length == 1
                        && java.util.List.class.isAssignableFrom(m.getReturnType())) {
                    aMethod = m;
                    break;
                }
            }
            if (aMethod != null) {
                XposedBridge.hookMethod(aMethod, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Object r = param.getResult();
                        if (r instanceof ArrayList) {
                            removeRegTasks((ArrayList<?>) r);
                        }
                    }
                });
                Log.i(TAG, "hooked l0.e.a() task-list factory");
            } else {
                Log.e(TAG, "l0.e.a() factory method not found");
            }
        } catch (Throwable t) {
            Log.e(TAG, "hook task factory err", t);
        }

        // 2) 兼 hook z0.k.d(Activity) 与 z0.s.d(Activity): 直接 return, 绝不弹卡密界面
        blockShow(CLS_REG_FULL, cl);
        blockShow(CLS_REG_CODE, cl);
    }

    /** 把任务列表里的注册/激活任务移除 */
    private void removeRegTasks(ArrayList<?> list) {
        try {
            Iterator<?> it = list.iterator();
            int removed = 0;
            while (it.hasNext()) {
                Object task = it.next();
                if (task == null) continue;
                String cn = task.getClass().getName();
                if (cn.equals(CLS_REG_FULL) || cn.equals(CLS_REG_CODE)) {
                    it.remove();
                    removed++;
                }
            }
            if (removed > 0) {
                Log.i(TAG, "removed " + removed + " register/activation task(s) from queue");
            }
        } catch (Throwable t) {
            Log.e(TAG, "removeRegTasks err", t);
        }
    }

    /** hook 指定类的 d(androidx.activity.m) 显示方法, 直接 return 防止弹窗 */
    private void blockShow(String className, ClassLoader cl) {
        try {
            Class<?> cls = Class.forName(className, false, cl);
            Method found = null;
            for (Method m : cls.getDeclaredMethods()) {
                // d 方法, 仅 1 个参数(Activity 或其父类), 返回 void
                if (m.getName().equals("d")
                        && m.getParameterTypes().length == 1
                        && m.getReturnType() == void.class
                        && Activity.class.isAssignableFrom(m.getParameterTypes()[0])) {
                    found = m;
                    break;
                }
            }
            if (found == null) {
                // 退一步: 参数类型可能不是 Activity 子类 (是 androidx.activity.m), 用名字 d + 1 参数 + void 兜底
                for (Method m : cls.getDeclaredMethods()) {
                    if (m.getName().equals("d")
                            && m.getParameterTypes().length == 1
                            && m.getReturnType() == void.class) {
                        found = m;
                        break;
                    }
                }
            }
            if (found != null) {
                XposedBridge.hookMethod(found, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        Log.i(TAG, "blocked show: " + param.method);
                        param.setResult(null);
                    }
                });
                Log.i(TAG, "hooked " + className + ".d() -> blocked");
            } else {
                Log.e(TAG, className + ".d() show method not found");
            }
        } catch (Throwable t) {
            Log.e(TAG, "blockShow err for " + className, t);
        }
    }
}
